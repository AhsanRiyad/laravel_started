<?php

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', 'LoginController@index');
Route::post('/login', 'LoginController@test');

Route::get('/home', ['as'=>'home.index', 'uses'=>'HomeController@index']);
Route::get('/home/profile', 'HomeController@profile')->name('home.profile');
Route::get('/home/add', 'HomeController@add');
Route::get('/ahjsdhjasdb/asjhdghjasbds', ['as'=>'home.stdlist', 'uses'=>'HomeController@stdlist']);
