<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>

	<h1>Welcome Home!</h1>

	<a href="home/profile">Profile</a> |
	<a href="{{route('home.stdlist')}}">Student List</a> |
	<a href="home/add">Add Student</a> |
	<a href="home/logout">Logout</a> 

</body>
</html>