<?php

namespace App\Http\Controllers;

use App\Http\Requests\AccountRequest;
use Illuminate\Http\Request;
use App\Account;
use Validator;

class AccountController extends Controller
{
    public function index(){

    	$acc = Account::all();

    	return view('accounts.index')->with('accounts', $acc);
    }

    public function show($accId){

    	$acc = Account::find($accId);
    	return view('accounts.show')->with('account', $acc);
    }
    public function create(){
    	return view('accounts.create');
    }

    public function store(AccountRequest $req){

/*        $this->validate($req, [
            "accNo"=>"required|unique:accounts",
            "accName"=>"required",
            "balance"=>"required",
            "typeId"=>"required"
        ]);*/

/*        $req->validate([
            "accNo"=>"required|unique:accounts",
            "accName"=>"required",
            "balance"=>"required",
            "typeId"=>"required"
        ]);*/

/*        $validation = Validator::make($req->all(),[
            "accNo"=>"required|unique:accounts",
            "accName"=>"required",
            "balance"=>"required",
            "typeId"=>"required"
        ]);*/

        //$validation->validate();

/*        if($validation->fails()){
            return back()->withErrors($validation->errors())
            ->withInput();
        }*/

/*        if($validation->fails()){
            return redirect()->route('account.create')
                ->withErrors($validation->errors())
                ->withInput();
        }*/


    	$account = new Account;
    	$account->accNo = $req->accNo;
    	$account->accName = $req->accName;
    	$account->balance = $req->balance;
    	$account->typeId = $req->typeId;
    	$account->lastTransaction =  date('Y-m-d H:i:s');
    	$account->save();
    	$acc = Account::where('accNo',$req->accNo)
    					->first();
    	return view('accounts.show')->with('account', $acc);
    }

 	public function edit($accId){
    	$acc = Account::find($accId);
    	return view('accounts.edit')->with('account', $acc);
    }

    public function update(Request $req, $accId){

    	$account 			= Account::find($accId);
    	$account->accNo 	= $req->accNo;
    	$account->accName 	= $req->accName;
    	$account->balance 	= $req->balance;
    	$account->typeId 	= $req->typeId;
    	$account->save();
    	return redirect()->route('account.show', $accId);
    }

    public function delete($accId){
    	$acc = Account::find($accId);
    	return view('accounts.delete')->with('account', $acc);
    }

    public function destroy($accId){
    	$acc = Account::destroy($accId);
    	return redirect()->route('account.index');
    }
}
