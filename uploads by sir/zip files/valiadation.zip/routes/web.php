<?php

Route::get('/', function () {
    return redirect()->route('login.index');
});

Route::get('/login', 'LoginController@index')->name('login.index');
Route::post('/login', 'LoginController@verify');
Route::get('/logout', 'LogoutController@index')->name('logout.index');
Route::get('/home', 'HomeController@index')->name('home.index');

Route::get('/accounts', 'AccountController@index')->name('account.index');

Route::get('/accounts/{accid}/details', 'AccountController@show')->name('account.show');
Route::get('/accounts/create', 'AccountController@create')->name('account.create');
Route::post('/accounts/create', 'AccountController@store');

Route::get('/accounts/{addid}/edit', 'AccountController@edit')->name('account.edit');

Route::post('/accounts/{addid}/edit', 'AccountController@update');

Route::get('/accounts/{addid}/delete', 'AccountController@delete')->name('account.delete');
Route::post('/accounts/{addid}/delete', 'AccountController@destroy');

Route::resource('acctype', 'AccountTypeController');