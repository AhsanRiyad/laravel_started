@extends('layouts.admin_main')

@section('abc')
<form method="post">
	<table>
		<tr>
			<td>Account No</td>
			<td><input type="text" name="accNo" value="{{old('accNo')}}"></td>
		</tr>
		<tr>
			<td>Account Name</td>
			<td><input type="text" name="accName" value="{{old('accName')}}"></td>
		</tr>
		<tr>
			<td>Balance</td>
			<td><input type="text" name="balance" value="{{old('balance')}}"></td>
		</tr>
		<tr>
			<td>Account Type</td>
			<td><input type="number" name="typeId" value="{{old('typeId')}}"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Create"></td>
		</tr>
	</table>
</form>

@foreach($errors->all() as $err)
	{{$err}} <br>
@endforeach
@endsection

@section('title')
Create
@endsection

