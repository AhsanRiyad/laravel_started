<!DOCTYPE html>
<html>
<head>
	<title>Account @yield('title')</title>
</head>
<body>
	<h1>Account @yield('title')</h1>

	<a href="{{route('account.index')}}">Account List</a> |
	<a href="{{route('account.create')}}">Create New</a> |
	<a href="{{route('logout.index')}}">Logout</a> 
	<br>
	<br>

	<a href="{{route('account.index')}}">Back to List</a>

<!-- content here -->
	
	@yield('abc')

</body>
</html>



