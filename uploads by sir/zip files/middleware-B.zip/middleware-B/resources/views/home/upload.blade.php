<!DOCTYPE html>

<html>
<head>
	<title>File Upload</title>
</head>
<body>

	<h1>File Upload</h1>

	<form method="post" enctype="multipart/form-data">
	
		<input type="hidden" name="_token" value="{{ csrf_token() }}">
		<input type="file" name="myfile"><br>
		<input type="submit" name="submit" value="Upload">
	</form>
</body>
</html>