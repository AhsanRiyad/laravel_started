<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UploadController extends Controller
{
    public function index(){

    	return view('home.upload');
    }

    public function store(Request $req){

    	if($req->hasFile('myfile')){

    		$file = $req->file('myfile');

    		echo "File name: ".$file->getClientOriginalName()."<br/>";
    		echo "File Extension: ".$file->getClientOriginalExtension()."<br/>";
    		echo "File Size: ".$file->getSize()."<br/>";
    		echo "File Mime Type: ".$file->getMimeType()."<br/>";

    		$file->move('upload', $file->getClientOriginalName());

    	}else{
    		echo "error";
    	}
    }
}
