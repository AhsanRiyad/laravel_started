<?php
require_once('iA.php');
require_once('iB.php');
require_once('iC.php');

class D implements iC
{
    public function a()
    {
        echo "Interface: A works <br/>";
    }

    public function b()
    {
        echo "Interface: B works <br/>";
    }

    public function c()
    {
        echo "Interface: C works <br/>";
    }
}

$obj = new D();
$obj->a();
$obj->b();
$obj->c();
