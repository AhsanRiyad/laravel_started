<?php
	
/*	$a = array(6, "XYZ",2.6);

	$a[0]=6;
	$a[1]="XYZ";
	$a[2]=2.6;*/

/*	$a = array("id"=>5, "name"=> "XYZ", "cgpa"=>2.5);

	$a['id'] = 5;
	$a['name'] = "XYZ";
	$a['cgpa'] = 2.5;*/

	$a[0]['id']=5;
	$a[0]['name']="XYZ";
	$a[0]['cgpa']=2.7;

	$a[1]['id']=5;
	$a[1]['name']="XYZ";
	$a[1]['cgpa']=2.7;

/*	$db = array(
		"mysql"=> array(
			"host" 		=> "127.0.0.1",
			"user" 		=> "root",
			"password"	=> "",
			"database"	=> 'test'
		),
		"sqlserver"=> array(
			"host" 		=> "127.0.0.1",
			"user" 		=> "root",
			"password"	=> "",
			"database"	=> 'ab'
		)
	);

	$db['mysql']['host']='127.0.0.1';
	$db['mysql']['user']='root';
	$db['mysql']['password']='';
	$db['mysql']['database']='test';

	$db['sqlserver']['host']='127.0.0.1';
	$db['sqlserver']['user']='root';
	$db['sqlserver']['password']='';
	$db['sqlserver']['database']='ab';

*/



