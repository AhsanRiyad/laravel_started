<?php

interface iC extends iA, iB
{
    public function c();
}