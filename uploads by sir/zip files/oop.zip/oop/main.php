<?php
	require_once('AbstractClass.php');

	class MainClass extends AbstractClass
	{
	    protected function test() {
	        return "Calling abstruct method";
	    }
	}

	$obj = new MainClass();
	echo $obj->printVal();