<?php

class Student{
	protected $name;
	private $id;
	private $cgpa;
	static $count=0;

	function __construct($name, $id, $cgpa){
		$this->name = $name;
		$this->id = $id;
		$this->cgpa = $cgpa;
	}

	function __construct($name, $id){
		$this->name = $name;
		$this->id = $id;
		$this->cgpa = $cgpa;
	}
	public function setName($name){
		$this->name = $name;
	}

	public function getName(){
		return $this->name;
	}
}

class CSStudent extends Student{

	function __construct(){
		Parent::__construct("ABC", 3, 3.5);
	}

}

echo Student::$count;


