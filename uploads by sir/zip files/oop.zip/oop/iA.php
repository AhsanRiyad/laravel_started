<?php
interface iA
{
    public function a();
}