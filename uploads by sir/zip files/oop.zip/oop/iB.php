<?php

interface iB
{
    public function b();
}