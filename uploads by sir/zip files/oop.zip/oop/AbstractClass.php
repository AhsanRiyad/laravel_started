<?php

	abstract class AbstractClass
	{
	    abstract protected function test();
	    
	    public function printVal() {
	        echo $this->test();
	    }
	}

	
