<?php
	
	class p1
	{
		private $name = "ABX";
		private $id = 111;

		function __construct($name, $id){
			$this->name = $name;
			$this->id = $id;
		}

		public function test(){
			echo "from base class";
		}
	}

	class p2 extends p1
	{
		function __construct(){
			Parent::__construct('alamin', '123');
		}
	}

	$p2 = new p2();
	echo $p2->test();

	