<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>

	<h1>Welcome Home! {{session('uname')}}</h1>

	<a href="/home">Profile</a> |
	<a href="/home">Student List</a> |
	<a href="/home">Add Student</a> |
	<a href="{{route('logout.index')}}">Logout</a> 

	<br>
	<br>
	<br>

	<table border="1">
		<tr>
			<td>ID</td>
			<td>NAME</td>
			<td>TAKEN</td>
			<td>COMPLETED</td>
			<td>ACTION</td>
		</tr>
	@foreach($stdList as $std)
		<tr>
			<td>{{$std[0]}}</td>
			<td>{{$std[1]}}</td>
			<td>{{$std[2]}}</td>
			<td>{{$std[3]}}</td>
			<td>
				<a href="{{route('home.edit', [$std[0]])}}">EDIT</a>|
				<a href="{{route('home.delete', [$std[0]])}}">DELETE</a>|
			</td>
		</tr>
	@endforeach

	</table>

</body>
</html>