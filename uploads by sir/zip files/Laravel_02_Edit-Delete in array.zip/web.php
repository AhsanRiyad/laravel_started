<?php

Route::get('/', function () {
    return redirect()->route('login.index');
});

Route::get('/login', 'LoginController@index')->name('login.index');
Route::post('/login', 'LoginController@verify');
Route::get('/logout', 'LogoutController@index')->name('logout.index');

Route::get('/home', ['as'=>'home.index', 'uses'=>'HomeController@index']);
Route::get('/home/edit/{sid}', 'HomeController@edit')->name('home.edit');
Route::post('/home/edit/{sid}', 'HomeController@update')->name('home.update');
Route::get('/home/delete/{sid}', 'HomeController@delete')->name('home.delete');

