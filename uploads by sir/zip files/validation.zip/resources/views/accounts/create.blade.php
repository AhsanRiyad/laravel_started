<!DOCTYPE html>
<html>
<head>
	<title>Account Details</title>
</head>
<body>
	<h1>Account Details</h1>

	<a href="{{route('account.index')}}">Back to List</a> |
	<a href="{{route('logout.index')}}">Logout</a> 

<form method="post">
	<table>
		<tr>
			<td>Account No</td>
			<td><input type="text" name="accNo" value="{{old('accNo')}}"></td>
		</tr>
		<tr>
			<td>Account Name</td>
			<td><input type="text" name="accName" value="{{old('accName')}}"></td>
		</tr>
		<tr>
			<td>Balance</td>
			<td><input type="text" name="balance" value="{{old('balance')}}"></td>
		</tr>
		<tr>
			<td>Account Type</td>
			<td><input type="number" name="typeId" value="{{old('typeId')}}"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Create"></td>
		</tr>
	</table>

	@foreach($errors->all() as $message)
			{{$message}} <br/>
	@endforeach
</form>
</body>
</html>