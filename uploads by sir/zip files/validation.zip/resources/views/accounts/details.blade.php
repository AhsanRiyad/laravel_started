<!DOCTYPE html>
<html>
<head>
	<title>Account Details</title>
</head>
<body>

<h1>Account Details</h1> 

	<a href="{{route('account.index')}}">Back to list</a> |
	<a href="{{route('account.edit', $account['accId'])}}">Edit</a> |
	<a href="{{route('account.delete', $account['accId'])}}">Delete</a>  |
	<a href="{{route('logout.index')}}">Logout</a> 
	<br>
	<br>

<form method="post">
	{{csrf_field()}}
	<table border="0" width="300px" >
		<tr>
			<td width="35%">Account No</td>
			<td width="2%">:</td>
			<td>{{$account['accNo']}}</td>
		</tr>
		<tr>
			<td>Account Name</td>
			<td>:</td>
			<td>{{$account['accName']}}</td>
		</tr>
		<tr>
			<td>Account Balance</td>
			<td>:</td>
			<td>{{$account['balance']}}</td>
		</tr>

		<tr>
			<td>Account Type</td>
			<td>:</td>
			<td>{{$account['typeId']}}</td>
		</tr>
		<tr>
			<td>Transaction</td>
			<td>:</td>
			<td>{{$account['lastTransaction']}}</td>
		</tr>
	</table>
</form>

</body>
</html>