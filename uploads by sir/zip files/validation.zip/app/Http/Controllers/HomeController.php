<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
	public function index(Request $req){

		$req->session()->put('uname', 'admin');
			
		$data = $this->studentList();
		return view('home.index')->with('stdList', $data);
	}

	public function edit($id){
        $data = $this->studentList();
        $std = "";
        foreach ($data as $s) {
            
            if($s[0]== $id){
                $std = $s;
                break;
            }
        }
        return view('home.edit')->withStd($std);
    }
    
    public function update(Request $req, $id){

        $std = [$id, $req->input('sname'), $req->taken, $req->completed];

        $data = $this->studentList();

        foreach ($data as &$s) {
            if($s[0]== $id){
                $s = $std;
                break;
            }
        }
        //var_dump($std);

        return view('home.index', ['stdList'=>$data]);
    }

    public function delete($id){
        $data = $this->studentList();
        $i = 0;
        foreach ($data as $s) {
            if($s[0]== $id){
                unset($data[$i]);
                break;
            }
            $i++;
        }
       return view('home.index', ['stdList'=>$data]);
    }

    public function studentList(){
        return [
				['12-11111-3', 'ABC PQR', 14, 130],
				['13-22222-2', 'XYZ PQR', 13, 135],
				['14-33333-1', 'PQR ABC', 12, 140],
				['15-44444-0', 'PQR XYZ', 10, 120],
		];
    }
}







