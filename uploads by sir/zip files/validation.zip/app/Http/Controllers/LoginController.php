<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    public function index(){

        //$users = User::all();

        //var_dump($users);

    	return view('login.index');
    }

    public function verify(Request $req){
        
        
/*        $user = User::where('username', $req->username)
            ->where('password', $req->password)
            ->first();*/

        $user = DB::table('users')->where('username', $req->username)
            ->where('password', $req->password)
            ->first();

    	if($user){
            $req->session()->put('uname', $req->username);
    		return redirect()->route('home.index');
    	}else{

            $req->session()->flash('msg', "Invalid username/password");
    		return redirect('/login');
            //return view('login.index');
    	}
    }
}
