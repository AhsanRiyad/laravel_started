<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AccountRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'accNo' => 'required|unique:accounts',
            'accName' => 'required',
            'balance' => 'required',
            'typeId' => 'required'
        ];
    }

    public function messages(){
        return [
            'accNo.required' => ':attribute field is empty',
            'accNo.unique' => 'Account No field is empty',
            'accName.required' => 'Account Name field is empty'
        ];
    }
}
